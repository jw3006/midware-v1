<?php
defined('BASEPATH') or exit('No direct script access allowed');

require(APPPATH . 'libraries/REST_Controller.php');

use Restserver\Libraries\REST_Controller;

class Get_token extends REST_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('template/bp_token');
        $this->load->library('keys_controller');
    }

    public function tokens_post()
    {
        $keys = $this->input->get_request_header('Authorization');
        $result = $this->keys_controller->_check_auth($keys);
        if ($result == true) {
            $type = $this->post('type');
            $this->response([
                'status' => true,
                'message' => 'The tokens data has been generated.',
                'data' => $type
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => 'fail',
                'message' => 'Authorization has been denied for this request.',
                'data' => ''
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }
}
