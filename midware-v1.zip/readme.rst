
*******************
Release Information
*******************

This repo contains in-development code for middleware with Bootstrap and 3rd party library. 
- Rest library
- Nusoap Library


